<!-- Sidebar -->
<div class="sidebar">
  <ul class="nav flex-column">

    <li class="nav-item">
      <a class="nav-link" href="?page=upcoming-courses">Upcoming Courses</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="?page=old-courses">Old Courses</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="?page=contact">Contact Us</a>
    </li>
    <?php if(isset($_SESSION['logged_in']) && $_SESSION['logged_in']==true){ ?>
      <li class="nav-item">
        <a class="nav-link" href="?page=my-courses">My Courses</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="?page=account">Account</a>
      </li>
      <?php if($_SESSION['user_role']=='admin'){ ?>
        <li class="nav-item">
          <a class="nav-link" href="admin">Admin Dashboard</a>
        </li>
      <?php } ?>
      <?php if($_SESSION['user_role']=='instructor'){ ?>
        <li class="nav-item">
          <a class="nav-link" href="instructor">Instructor Dashboard</a>
        </li>
      <?php } ?>
      <li class="nav-item">
        <a class="nav-link" href="?page=logout">Logout</a>
      </li>
  <?php }else { ?>
    <li class="nav-item">
      <a class="nav-link" href="?page=login">Login</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="?page=register">Register</a>
    </li>
  <?php  } ?>
  </ul>
</div>
