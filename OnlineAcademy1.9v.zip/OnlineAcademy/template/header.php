<?php
session_start();
require_once 'config/app.php';
require_once 'logger/logger.php';
?>
<!DOCTYPE html>
<html lang=<?php echo $config['lang']; ?> dir=<?php echo $config['dir']; ?>>
<head>
  <meta charset="utf-8">
  <title><?php echo $config['app_name'] . " | " . $title; ?></title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    /* Add your custom styles here */
    /* Example custom style: increase table row height */
    .table tbody tr {
      height: 50px;
    }
    .sidebar {
      width: 200px;
      background-color: #f5f5f5;
      padding: 20px;
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      overflow-y: auto;
    }
    .sidebar ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    .sidebar li {
      margin-bottom: 10px;
    }
    .sidebar a {
      text-decoration: none;
      color: #333;
    }
    .sidebar a:hover {
      color: #666;
    }
    .content {
      margin-left: 220px; /* Adjust the margin to make space for the sidebar */
      padding: 20px;
    }
  </style>
</head>

<body>
  <div class="container pt-5">
    <?php include 'messages.php'; ?>
    <!-- Your header content here (e.g., navigation, logo) -->
