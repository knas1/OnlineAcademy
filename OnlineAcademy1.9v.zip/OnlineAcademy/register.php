<?php
$title = "Register Page";
require_once 'template/header.php';
require_once 'config/database.php';
?>
<!-- Add Font Awesome CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<?php
if (isset($_SESSION['logged_in'])) {
    header("location:" . $config['app_url']);
    die();
}

$errors = [];
$email = '';
$name = '';
$password = '';
$password_confirmation = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($mysqli, $_POST['email']);
    $name = mysqli_real_escape_string($mysqli, $_POST['name']);
    $password = mysqli_real_escape_string($mysqli, $_POST['password']);
    $password_confirmation = mysqli_real_escape_string($mysqli, $_POST['password_confirmation']);

    if (empty($email)) array_push($errors, "Email is required");
    if (empty($name)) array_push($errors, "Name is required");
    if (empty($password)) array_push($errors, "Password is required");
    if (empty($password_confirmation)) array_push($errors, "Password Confirmation is required");
    if ($password != $password_confirmation) array_push($errors, "Password doesn't match");

    // Check password requirements
    $password_length = strlen($password);
    if ($password_length < 8) array_push($errors, "Password must be at least 8 characters long");
    if (!preg_match("/[A-Z]/", $password)) array_push($errors, "Password must contain at least one uppercase letter");
    if (!preg_match("/[a-z]/", $password)) array_push($errors, "Password must contain at least one lowercase letter");
    if (!preg_match("/[0-9]/", $password)) array_push($errors, "Password must contain at least one number");

    if ( !count($errors) ) {

      $password=password_hash($password,PASSWORD_DEFAULT);

      $InsertQuery = "insert into users(email,name,password) values ('$email','$name','$password')";
      $mysqli ->query($InsertQuery);

      // Log file
      $logger = Logger::getInstance();
      $log = "New User has been created using this email :".$email;
      $logger->log($log);


      $_SESSION['success_message'] = "Registered successed";
      header('location: index.php?page=login');
      die();
    }

}
?>
<script>
    function updatePasswordRequirements() {
        const passwordInput = document.getElementById("password");
        const passwordConfirmationInput = document.getElementById("password_confirmation");
        const passwordRequirements = document.getElementById("password-requirements");
        const requirementsList = document.getElementById("requirements-list");
        const passwordMismatch = document.getElementById("password-mismatch");

        const password = passwordInput.value;
        const passwordConfirmation = passwordConfirmationInput.value;

        // Check password length
        const lengthRequirement = password.length >= 8;
        // Check uppercase letter
        const uppercaseRequirement = /[A-Z]/.test(password);
        // Check lowercase letter
        const lowercaseRequirement = /[a-z]/.test(password);
        // Check number
        const numberRequirement = /\d/.test(password);

        // Update requirements list
        requirementsList.innerHTML = '';
        if (!lengthRequirement) requirementsList.innerHTML += '<li>Be at least 8 characters long</li>';
        if (!uppercaseRequirement) requirementsList.innerHTML += '<li>Contain at least one uppercase letter</li>';
        if (!lowercaseRequirement) requirementsList.innerHTML += '<li>Contain at least one lowercase letter</li>';
        if (!numberRequirement) requirementsList.innerHTML += '<li>Contain at least one number</li>';

        // Update passwordRequirements message
        if (lengthRequirement && uppercaseRequirement && lowercaseRequirement && numberRequirement) {
            passwordRequirements.style.color = 'green';
            passwordRequirements.innerHTML = 'Password meets the requirements.';
            requirementsList.style.display = 'none';
        } else {
            passwordRequirements.style.color = 'red';
            passwordRequirements.innerHTML = 'Password must:';
            requirementsList.style.display = 'block';
        }

        // Check password confirmation
        if (password === passwordConfirmation) {
            passwordMismatch.style.display = 'none';
        } else {
            passwordMismatch.style.display = 'block';
        }
    }

    function togglePasswordVisibility(inputId, iconId) {
        const input = document.getElementById(inputId);
        const icon = document.getElementById(iconId);

        if (input.type === "password") {
            input.type = "text";
            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
        } else {
            input.type = "password";
            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
        }
    }
</script>

<div class="register">
    <h4>Welcome to our website</h4>
    <h3 class="text-info">Please fill in the form below to register a new account</h3>
    <hr>

    <?php include 'template/errors.php'; ?>
    <form action="" method="post">
        <div class="form-group">
            <label for="email">Email:</label>
            <input class="form-control" type="email" name="email" placeholder="Your Email" value="<?php echo $email; ?>"
                id="email">
        </div>

        <div class="form-group">
            <label for="name">Name:</label>
            <input class="form-control" type="text" name="name" placeholder="Your name" value="<?php echo $name; ?>"
                id="name">
        </div>

        <div class="form-group">
            <label for="password">Password:</label>
            <div class="password-field">
                <input class="form-control" type="password" name="password" placeholder="Your password" id="password"
                    onkeyup="updatePasswordRequirements();">
                <i id="toggle-password" class="fas fa-eye" onclick="togglePasswordVisibility('password', 'toggle-password')"></i>
            </div>
            <p id="password-requirements" style="color: red;">Password must:</p>
            <ul id="requirements-list" style="color: red;"></ul>
        </div>

        <div class="form-group">
            <label for="confirm_password">Confirm Password:</label>
            <input class="form-control" type="password" name="password_confirmation" placeholder="Confirm your password"
                id="password_confirmation" onkeyup="updatePasswordRequirements();">
            <p id="password-mismatch" style="color: red; display: none;">Password confirmation doesn't match.</p>
        </div>

        <div class="form-groupd">
            <button class="btn btn-success">Register</button>
            <a href="login.php">Already have an account</a>
        </div>
    </form>
</div>

<?php
require_once 'template/footer.php';
?>
