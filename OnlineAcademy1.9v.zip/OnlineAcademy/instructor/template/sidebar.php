<div class="sidebar-wrapper">
    <div class="logo">
        <a href="<?php echo $config['app_url']."admin" ?>" class="simple-text">
            Instructor Panel
        </a>
    </div>
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo $config['app_url'] ?>">
                <i class="nc-icon nc-chart-pie-35"></i>
                <p>User Dashboard</p>
            </a>
        </li>
        <li>
            <a class="nav-link" href="<?php echo $config['app_url'] ?>instructor/courses">
                <i class="nc-icon nc-notes"></i>
                <p>My Courses</p>
            </a>
        </li>
        <!-- <li>
            <a class="nav-link" href="<?php echo $config['app_url'] ?>admin/template/examples/icons.html">
                <i class="nc-iear-64"></i>
                <p>Icons</p>
            </a>
        </li> -->
    </ul>
</div>
