<?php
$title = "Add courses";
$icon = "nc-layers-3";
include __DIR__.'/../template/header.php';

$errors = [];

// Fetch instructors from the database
$instructors = $mysqli->query("SELECT * FROM users where role='instructor';")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $title = mysqli_real_escape_string($mysqli, $_POST['title']);
  $description = mysqli_real_escape_string($mysqli, $_POST['description']);
  $link = mysqli_real_escape_string($mysqli, $_POST['link']);
  $status = $_POST['status'];
  $date = $_POST['date'];
  $capacity = $_POST['capacity'];
  $instructor_id = $_SESSION['user_id'];

  if (empty($title)) {
    array_push($errors, "Title is required");
  }
  if (empty($description)) {
    array_push($errors, "Description is required");
  }

  if (!count($errors)) {
    $st = $mysqli->prepare("INSERT INTO courses (title, description, link, status, date, capacity, instructor_id, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $st->bind_param("ssssssis", $title, $description, $link, $status, $date, $capacity, $instructor_id, $image_filename);

    // Handle course image
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
      $image_upload_path = '../../courses_image/';
      $image_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
      $image_filename = 'course_' . uniqid() . '.' . $image_extension;

      // Check if the file is an image
      $valid_image_extensions = ['jpg', 'jpeg', 'png', 'gif'];
      if (!in_array($image_extension, $valid_image_extensions)) {
        array_push($errors, "Invalid image file. Only JPG, JPEG, PNG, and GIF formats are allowed.");
      } elseif ($_FILES['image']['size'] > 2097152) { // Max file size: 2 MB
        array_push($errors, "Image size exceeds the maximum allowed limit of 2MB.");
      } else {
        // Move the uploaded file to the desired location
        move_uploaded_file($_FILES['image']['tmp_name'], $image_upload_path . $image_filename);
      }
    } else {
      $image_filename = null; // No image provided
    }

    $st->execute();

    if ($st->error) {
      array_push($errors, $st->error);
    } else {
      echo "<script>location.href='index.php'</script>";
    }
  }
}
?>

<div class="card">
  <div class="content">
    <?php include __DIR__.'/../template/errors.php'; ?>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="title">Title:</label>
        <input class="form-control" type="text" name="title" placeholder="Course Title" value="<?php echo isset($_POST['title']) ? $_POST['title'] : ''; ?>" id="title">
      </div>
      <div class="form-group">
        <label for="description">Description:</label>
        <textarea class="form-control" name="description" placeholder="Course Description" id="description"><?php echo isset($_POST['description']) ? $_POST['description'] : ''; ?></textarea>
      </div>
      <div class="form-group">
        <label for="link">Link:</label>
        <input class="form-control" type="text" name="link" placeholder="Course Link" value="<?php echo isset($_POST['link']) ? $_POST['link'] : ''; ?>" id="link">
      </div>
      <div class="form-group">
        <label for="status">Status:</label>
        <select class="form-control" name="status" id="status">
          <option value="upcoming">Upcoming</option>
          <option value="finished">Finished</option>
        </select>
      </div>
      <div class="form-group">
        <label for="date">Date:</label>
        <input class="form-control" type="text" name="date" placeholder="Course Date" value="<?php echo isset($_POST['date']) ? $_POST['date'] : ''; ?>" id="date">
      </div>
      <div class="form-group">
        <label for="capacity">Capacity:</label>
        <input class="form-control" type="text" name="course_capacity" placeholder="Course Capacity" value="<?php echo isset($_POST['course_capacity']) ? $_POST['course_capacity'] : ''; ?>" id="course_capacity">
      </div>
      <div class="form-group">
        <label for="image">Course Image:</label>
        <input class="form-control" type="file" name="image" id="image">
      </div>
      <div class="form-group">
        <button class="btn btn-success">Create</button>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__.'/../template/footer.php'; ?>
