<?php
$title = "Courses";
$icon = "nc-layers-3";
include __DIR__.'/../template/header.php';

$instructorId = $_SESSION['user_id'];

$courses = $mysqli->query("SELECT * FROM courses WHERE instructor_id = $instructorId ORDER BY id")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $st = $mysqli->prepare("DELETE FROM courses WHERE id = ?");
  $st->bind_param("i", $IdToDelete);
  $IdToDelete = $_POST['course_id'];
  $st->execute();

  if ($st->error) {
    echo $st->error;
  } else {
    echo "<script>location.href='index.php'</script>";
  }
}
?>

<div class="card">
  <div class="card-body">
    <div class="content">

      <a href="create.php" class="btn btn-success">Create a new course</a>
      <p>Courses: <?php echo count($courses); ?></p>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>Title</th>
              <th>Description</th>
              <th>Link</th>
              <th>Status</th>
              <th>Date</th>
              <th>Capacity</th>
              <th>Taken seats</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            <?php foreach ($courses as $course): ?>
              <tr>
                <td><?php echo $course["id"]; ?></td>
                <td><?php echo $course["title"]; ?></td>
                <td><?php echo $course["description"]; ?></td>
                <td><?php echo $course["link"]; ?></td>
                <td><?php echo $course["status"]; ?></td>
                <td><?php echo $course["date"]; ?></td>
                <td><?php echo $course["capacity"]; ?></td>
                <td><?php echo $course["taken_seats"]; ?></td>
                <td>
                  <a href="courses.php?id=<?php echo $course["id"]; ?>" class="btn btn-warning">Registered Users</a>
                  <form action="" method="post" style="display: inline">
                  <a href="edit.php?id=<?php echo $course["id"]; ?>" class="btn btn-warning">Edit</a>
                  <form action="" method="post" style="display: inline">
                    <input type="hidden" name="course_id" value="<?php echo $course["id"]; ?>">
                    <button onclick="confirm('Are you sure?')" class="btn btn-danger" type="submit" name="button">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</div>

<?php include __DIR__.'/../template/footer.php'; ?>
