<?php
$title = "Edit courses";
$icon = "nc-layers-3";
include __DIR__.'/../template/header.php';

if (!isset($_GET["id"]) || !$_GET["id"]) {
  die("Missing parameter");
}

$errors = [];

$course_id = $_GET["id"];
$st = $mysqli->prepare("SELECT * FROM courses WHERE id = ?");
$st->bind_param("i", $course_id);
$st->execute();

$course = $st->get_result()->fetch_assoc();

$course_title = $course['title'];
$course_description = $course['description'];
$course_link = $course['link'];
$course_status = $course['status'];
$course_date = $course['date'];
$course_capacity = $course['capacity'];
$course_image_name = basename($course['image_path']);

// Fetch instructors from the database
$instructors = $mysqli->query("SELECT * FROM users where role='instructor';")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  if (empty($_POST['course_title'])) {
    array_push($errors, "Course title is required");
  }
  if (empty($_POST['course_description'])) {
    array_push($errors, "Course description is required");
  }

  if (!count($errors)) {
    $st = $mysqli->prepare("UPDATE courses SET title = ?, description = ?, link = ?, status = ?, date = ?, capacity = ?, image_path = ? WHERE id = ?");
    $st->bind_param("sssssisi", $title, $description, $link, $status, $date, $capacity, $image_path, $course_id);

    $title = $_POST['course_title'];
    $description = $_POST['course_description'];
    $link = $_POST['course_link'];
    $status = $_POST['course_status'];
    $date = $_POST['course_date'];
    $capacity = !empty($_POST['course_capacity']) ? $_POST['course_capacity'] : null;
    $image_path = $course_image_name; // Preserve the existing image name by default

    // Handle course image deletion
    if (isset($_POST['delete_image']) && $_POST['delete_image'] === 'on') {
      // User requested to delete the existing image
      if (!empty($course_image_name) && file_exists('../../courses_image/' . $course_image_name)) {
        unlink('../../courses_image/' . $course_image_name);
        $image_path = ''; // Clear the image_path in the database
      }
    }

    // Handle course image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
      $image_upload_path = '../../courses_image/';
      $image_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
      $image_path = uniqid('course_') . '.' . $image_extension;

      // Check if the file is an image
      $valid_image_extensions = ['jpg', 'jpeg', 'png', 'gif'];
      if (!in_array($image_extension, $valid_image_extensions)) {
        array_push($errors, "Invalid image file. Only JPG, JPEG, PNG, and GIF formats are allowed.");
      } elseif ($_FILES['image']['size'] > 2097152) { // Max file size: 2 MB
        array_push($errors, "Image size exceeds the maximum allowed limit of 2MB.");
      } else {
        // Move the uploaded file to the desired location
        move_uploaded_file($_FILES['image']['tmp_name'], $image_upload_path . $image_path);

        // Delete the existing image if there was one
        if (!empty($course_image_name) && file_exists('../../courses_image/' . $course_image_name)) {
          unlink('../../courses_image/' . $course_image_name);
        }
      }
    }

    $st->execute();

    if ($st->error) {
      array_push($errors, $st->error);
    } else {
      echo "<script>location.href='index.php'</script>";
    }
  }
}
?>

<div class="card">
  <div class="content">
    <?php include __DIR__.'/../template/errors.php'; ?>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="title">Title:</label>
        <input class="form-control" type="text" name="course_title" placeholder="Course Title" value="<?php echo $course_title; ?>" id="title">
      </div>
      <div class="form-group">
        <label for="description">Description:</label>
        <textarea class="form-control" name="course_description" placeholder="Course Description" id="description"><?php echo $course_description; ?></textarea>
      </div>
      <div class="form-group">
        <label for="link">Link:</label>
        <input class="form-control" type="text" name="course_link" placeholder="Course Link" value="<?php echo $course_link; ?>" id="link">
      </div>
      <div class="form-group">
        <label for="status">Status:</label>
        <select class="form-control" name="course_status" id="status">
          <option value="upcoming" <?php echo ($course_status == "upcoming") ? "selected" : ""; ?>>Upcoming</option>
          <option value="finished" <?php echo ($course_status == "finished") ? "selected" : ""; ?>>Finished</option>
        </select>
      </div>
      <div class="form-group">
        <label for="date">Date:</label>
        <input class="form-control" type="text" name="course_date" placeholder="Course Date" value="<?php echo $course_date; ?>" id="date">
      </div>
      <div class="form-group">
        <label for="capacity">Capacity:</label>
        <input class="form-control" type="text" name="course_capacity" placeholder="Course Capacity" value="<?php echo $course_capacity; ?>" id="capacity">
      </div>

      <div class="form-group">
        <label for="existing_image">Existing Image:</label>
        <?php if (!empty($course_image_name) && file_exists('../../courses_image/' . $course_image_name)) : ?>
          <img src="../../courses_image/<?php echo $course_image_name; ?>" alt="Course Image" style="max-height: 200px;">
          <input type="hidden" name="existing_image_name" value="<?php echo $course_image_name; ?>">
          <br>
          <input type="checkbox" name="delete_image" id="delete_image">
          <label for="delete_image">Delete Image</label>
        <?php else : ?>
          <p>No image available</p>
        <?php endif; ?>
      </div>

      <div class="form-group">
        <label for="image">Upload New Image:</label>
        <input class="form-control" type="file" name="image" id="image">
      </div>

      <div class="form-group">
        <button class="btn btn-success">Update</button>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__.'/../template/footer.php'; ?>
