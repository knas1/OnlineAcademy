<?php
require_once 'template/header.php';

if ($_SESSION['logged_in'] == true) {
  $userId = $_SESSION['user_id'];

  // Fetch the courses the user has signed up for along with the instructor name
  $query = "SELECT c.title, c.description, c.link, c.date, u.name AS instructor_name, cert.certificate_name
            FROM courses c
            INNER JOIN registrations r ON c.id = r.course_id
            INNER JOIN users u ON c.instructor_id = u.id
            LEFT JOIN certificates cert ON c.id = cert.course_id AND r.user_id = cert.user_id
            WHERE r.user_id = $userId";
  $result = $mysqli->query($query);

  if (!$result) {
    die('Error fetching user courses: ' . $mysqli->error);
  }

  // Display the user's courses
  if ($result->num_rows > 0) {
    echo '<div class="container">';
    echo '<h2>Your Courses</h2>';
    echo '<table class="table">';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Title</th>';
    echo '<th>Description</th>';
    echo '<th>Link</th>';
    echo '<th>Date</th>';
    echo '<th>Instructor</th>';
    echo '<th>Certificate</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';

    while ($row = $result->fetch_assoc()) {
      echo '<tr>';
      echo '<td>' . $row['title'] . '</td>';
      echo '<td>' . $row['description'] . '</td>';
      if (empty($row['link'])) {
        echo '<td> No Link yet </td>';
      } else {
        echo '<td><a href="' . $row['link'] . '">' . ' Link</a></td>';
      }
      echo '<td>' . date('F j, Y', strtotime($row['date'])) . '</td>';
      echo '<td>' . $row['instructor_name'] . '</td>';
      echo '<td>';
      if (!empty($row['certificate_name'])) {
        $certificateFileName = $row['certificate_name'];
        echo '<a href='.$config['app_url'].'certificates/' . $certificateFileName . ' download>Download Certificate</a>';
      } else {
        echo 'No Certificate';
      }
      echo '</td>';
      echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
    echo '</div>';
  } else {
    echo '<div class="container">';
    echo '<h2>Your Courses</h2>';
    echo '<p>You have not signed up for any courses yet.</p>';
    echo '</div>';
  }
} else {
  echo '<div class="container">';
  echo '<h2>Your Courses</h2>';
  echo '<p>Please log in to view your courses.</p>';
  echo '</div>';
}

require_once 'template/footer.php';
?>
