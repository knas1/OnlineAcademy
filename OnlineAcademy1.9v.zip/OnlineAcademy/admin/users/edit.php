<?php
$title = "Edit User";
$icon = "nc-badge";
include __DIR__.'/../template/header.php';


if(!isset($_GET["id"]) || !$_GET["id"]){
  die("Missing parameter");
}



$errors=[];

$user_id = $_GET["id"];
$st = $mysqli -> prepare("select * from users where id = ?");
$st -> bind_param("i", $user_id);
$st->execute();

$user = $st->get_result()->fetch_assoc();

$email= $user['email'];
$name = $user['name'];
$mobile = $user['mobile'];
$role = $user['role'];

if($_SERVER['REQUEST_METHOD'] == 'POST'){

  if(empty($_POST['email']))array_push($errors,"Email is required");
  if(empty($_POST['name']))array_push($errors,"Name is required");
  if(empty($_POST['role']))array_push($errors,"Role is required");

  // Validate password if provided
  $password = $_POST['password'];
  if (!empty($password)) {
      // Check password requirements
      $lengthRequirement = strlen($password) >= 8;
      $uppercaseRequirement = preg_match('/[A-Z]/', $password);
      $lowercaseRequirement = preg_match('/[a-z]/', $password);
      $numberRequirement = preg_match('/\d/', $password);

      if (!$lengthRequirement || !$uppercaseRequirement || !$lowercaseRequirement || !$numberRequirement) {
          array_push($errors, "Password must meet the requirements.");
      }
  }

  if ( !count($errors) ) {

    $st = $mysqli->prepare("update users set name = ?, email =?, password = ?, mobile=?, role = ? where id=$user_id ");
    $st -> bind_param("sssss", $dbname, $dbemail, $dbpassword, $dbmobile, $dbrole );

    $dbemail= $_POST['email'];
    $dbname = $_POST['name'];
    $_POST['password'] ? $dbpassword = password_hash($_POST['password'],PASSWORD_DEFAULT) : $dbpassword = $user['password'];
    $dbrole = $_POST['role'];
    $dbmobile = $_POST['mobile'];

    $st->execute();

    if($st -> error){
      array_push($errors,$st -> error);
    }else {
      echo "<script>location.href='index.php'</script>";
    }

  }


}

?>

<div class="card">
  <div class="content">

    <?php  include __DIR__.'/../template/errors.php'; ?>
    <form action="" method="post">

      <div class="form-group">
        <label for="email">Email:</label>
        <input class="form-control" type="email" name="email" placeholder="User's Email" value="<?php echo $email; ?>" id="email">
      </div>

      <div class="form-group">
        <label for="name">Name:</label>
        <input class="form-control" type="text" name="name" placeholder="User's name" value="<?php echo $name; ?>" id="name">
      </div>

      <div class="form-group">
    <label for="mobile">Mobile:</label>
    <input class="form-control" type="tel" name="mobile" placeholder="05XXXXXXXX" value="<?php echo $mobile; ?>" id="mobile" pattern="05\d{8}" >
    <p class="text-muted">Mobile number must start with '05' and have 10 digits.</p>
      </div>


      <!-- Password input field with requirements -->
      <div class="form-group">
        <label for="password">Password:</label>
        <div class="password-field">
            <input class="form-control" type="password" name="password" placeholder="User's password" id="password"
                onkeyup="updatePasswordRequirements();">
            <i id="toggle-password" class="fas fa-eye" onclick="togglePasswordVisibility('password', 'toggle-password')"></i>
        </div>
        <!-- Display password requirements -->
        <p id="password-requirements" style="color: red;">Password must:</p>
        <ul id="requirements-list" style="color: red;"></ul>
      </div>

      <!-- JavaScript functions for password requirements and visibility toggle -->
      <script>
        function updatePasswordRequirements() {
            const passwordInput = document.getElementById("password");
            const passwordRequirements = document.getElementById("password-requirements");
            const requirementsList = document.getElementById("requirements-list");

            const password = passwordInput.value;

            // Check password length
            const lengthRequirement = password.length >= 8;
            // Check uppercase letter
            const uppercaseRequirement = /[A-Z]/.test(password);
            // Check lowercase letter
            const lowercaseRequirement = /[a-z]/.test(password);
            // Check number
            const numberRequirement = /\d/.test(password);

            // Update requirements list
            requirementsList.innerHTML = '';
            if (!lengthRequirement) requirementsList.innerHTML += '<li>Be at least 8 characters long</li>';
            if (!uppercaseRequirement) requirementsList.innerHTML += '<li>Contain at least one uppercase letter</li>';
            if (!lowercaseRequirement) requirementsList.innerHTML += '<li>Contain at least one lowercase letter</li>';
            if (!numberRequirement) requirementsList.innerHTML += '<li>Contain at least one number</li>';

            // Update passwordRequirements message
            if (lengthRequirement && uppercaseRequirement && lowercaseRequirement && numberRequirement) {
                passwordRequirements.style.color = 'green';
                passwordRequirements.innerHTML = 'Password meets the requirements.';
                requirementsList.style.display = 'none';
            } else {
                passwordRequirements.style.color = 'red';
                passwordRequirements.innerHTML = 'Password must:';
                requirementsList.style.display = 'block';
            }
        }

        function togglePasswordVisibility(inputId, iconId) {
            const input = document.getElementById(inputId);
            const icon = document.getElementById(iconId);

            if (input.type === "password") {
                input.type = "text";
                icon.classList.remove("fa-eye");
                icon.classList.add("fa-eye-slash");
            } else {
                input.type = "password";
                icon.classList.remove("fa-eye-slash");
                icon.classList.add("fa-eye");
            }
        }
      </script>


      <div class="form-group">
        <label for="role">Role:</label>
        <select name="role" class="form-control">
          <option value="user"
          <?php if($role == 'user') echo "selected"; ?>
          >User</option>
          <option value="instructor"
          <?php if($role == 'instructor') echo "selected"; ?>
          >Instructor</option>
          <option value="admin"
          <?php if($role == 'admin') echo "selected"; ?>
          >Admin</option>

        </select>
      </div>

      <div class="form-groupd">
        <button class="btn btn-success">Update</button>
      </div>

    </form>

  </div>
</div>



<?php
include  __DIR__.'/../template/footer.php'; ?>
