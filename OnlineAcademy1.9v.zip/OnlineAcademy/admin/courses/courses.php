<?php
ob_start();
$title = "Registered Users";
$icon = "nc-layers-3";
include __DIR__.'/../template/header.php';

$courseId = $_GET['id'];
$courseQuery = "SELECT * FROM courses WHERE id = $courseId";
$courseResult = $mysqli->query($courseQuery);
$course = $courseResult->fetch_assoc();

$registeredUsersQuery = "
  SELECT u.id, u.name, u.email
  FROM users u
  INNER JOIN registrations r ON u.id = r.user_id
  WHERE r.course_id = $courseId
";
$registeredUsersResult = $mysqli->query($registeredUsersQuery);
$registeredUsers = $registeredUsersResult->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['send_reminder'])) {
    require '../../sendMail.php'; // Include the send.php file for email sending functionality

    $messages = []; // Array to collect messages from sendEmail function

    // Send email reminder to all registered users
    foreach ($registeredUsers as $user) {
      $recipientEmail = $user['email'];
      $subject = 'Reminder: Course Registration';
      $message = 'Dear ' . $user['name'] . ',\n\nThis is a reminder about the upcoming course "' . $course['title'] . '". The course will start on ' . $course['date'] . '. Please make sure to attend the course on time.\n\nBest regards,\nYour Course Team';

      // Call the sendEmail function from send.php to send the email and collect the messages
      $messages[] = sendEmail($recipientEmail, $subject, $message);
    }

    // Display the alert based on the messages collected
    if (in_array('Reminder Email could not be sent. Error: ', $messages)) {
      echo "<script>alert('Reminder Email could not be sent. Please check the email settings and try again.');</script>";
    } else {
      echo "<script>alert('Reminder Emails Sent Successfully');</script>";
    }
  } elseif (isset($_POST['issue_certificates'])) {
    require_once('../../tcpdf/tcpdf.php');

    // Loop through registered users and generate certificates
    foreach ($registeredUsers as $user) {
      // Check if the user already has a certificate for the same course
      $certificateQuery = "SELECT * FROM certificates WHERE user_id = {$user['id']} AND course_id = $courseId";
      $certificateResult = $mysqli->query($certificateQuery);
      $existingCertificate = $certificateResult->fetch_assoc();

      if (!$existingCertificate) {
        $name = $user['name'];
        $courseName = 'Has successfully completed all tasks required to pass the course<br> ' . $course['title']; // Add the desired text before the course name
        $courseDate = $course['date'];

        // Load the PDF template with horizontal orientation
        $pdf = new TCPDF('L', 'mm', 'A4', true, 'UTF-8');

        // Set the page orientation to landscape
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->AddPage('L');

        // Set the background image
        $imagePath = __DIR__.'/../../certificates/Certificate.jpg'; // Replace with the path to your background image
        $imageX = 20; // X coordinate for the image position
        $imageY = 0; // Y coordinate for the image position
        $imageWidth = $pdf->getPageWidth(); // Width of the image
        $imageHeight = $pdf->getPageHeight(); // Height of the image
        $pdf->Image($imagePath, $imageX, $imageY, $imageWidth, $imageHeight, '', '', '', false, 300, '', false, false, 0);

        // Set the font and font size for the name, course name, and course date
        $pdf->SetFont('times', 'B', 36);
        $pdf->SetFontSize(20);

        // Set the color for the text elements
        $pdf->SetTextColor(255, 0, 0); // Replace with your desired text color

        // Write the name, course name, and course date onto the certificate using HTML
        $html = '
          <div style="position: absolute; text-align: center; top: 10mm; line-height: 6.0;"> </div>
          <div style="position: absolute; text-align: center; top: 30mm; line-height: 1.5;">' . $name . '</div>
          <div style="position: absolute; text-align: center; top: 40mm; line-height: 1.5;">' . $courseName . '</div>
          <div style="position: absolute; text-align: center; top: 50mm; line-height: 1.5;">' . $courseDate . '</div>
        ';
        $pdf->writeHTML($html, true, false, false, false, '');

        // Output the PDF as a file with a unique filename based on user ID and timestamp
        $filename = 'certificate_' . time() . '.pdf';
        $pdf->Output(__DIR__.'/../../certificates/' . $filename, 'F');

        // Save certificate data in the database
        $insertCertificateQuery = "INSERT INTO certificates (user_id, course_id, certificate_name) VALUES ({$user['id']}, $courseId,  '$filename')";
        $mysqli->query($insertCertificateQuery);
        sleep(1); // The sleep time to avoid collision in creating 2 files
      }
    }
  } elseif (isset($_POST['delete_certificate'])) {
    // Handle certificate deletion
    $userId = $_POST['user_id'];
    $deleteCertificateQuery = "DELETE FROM certificates WHERE user_id = $userId AND course_id = $courseId";
    $mysqli->query($deleteCertificateQuery);

    // Delete the certificate file from the server
    $certificateFile = $_POST['certificate_name'];
    $certificatePath = __DIR__.'/../../certificates/' . $certificateFile;
    if (file_exists($certificatePath)) {
      unlink($certificatePath);
    }
  } elseif (isset($_POST['issue_single_certificate'])) {
    require_once('../../tcpdf/tcpdf.php');

    $userId = $_POST['user_id'];
    $userQuery = "SELECT * FROM users WHERE id = $userId";
    $userResult = $mysqli->query($userQuery);
    $user = $userResult->fetch_assoc();

    // Check if the user already has a certificate for the same course
    $certificateQuery = "SELECT * FROM certificates WHERE user_id = {$user['id']} AND course_id = $courseId";
    $certificateResult = $mysqli->query($certificateQuery);
    $existingCertificate = $certificateResult->fetch_assoc();

    if (!$existingCertificate) {
      $name = $user['name'];
      $courseName = 'Has successfully completed all tasks required to pass the course<br> ' . $course['title']; // Add the desired text before the course name
      $courseDate = $course['date'];

      // Load the PDF template with horizontal orientation
      $pdf = new TCPDF('L', 'mm', 'A4', true, 'UTF-8');

      // Set the page orientation to landscape
      $pdf->setPrintHeader(false);
      $pdf->setPrintFooter(false);
      $pdf->AddPage('L');

      // Set the background image
      $imagePath = __DIR__.'/../../certificates/Certificate.jpg'; // Replace with the path to your background image
      $imageX = 20; // X coordinate for the image position
      $imageY = 0; // Y coordinate for the image position
      $imageWidth = $pdf->getPageWidth(); // Width of the image
      $imageHeight = $pdf->getPageHeight(); // Height of the image
      $pdf->Image($imagePath, $imageX, $imageY, $imageWidth, $imageHeight, '', '', '', false, 300, '', false, false, 0);

      // Set the font and font size for the name, course name, and course date
      $pdf->SetFont('times', 'B', 36);
      $pdf->SetFontSize(20);

      // Set the color for the text elements
      $pdf->SetTextColor(255, 0, 0); // Replace with your desired text color

      // Write the name, course name, and course date onto the certificate using HTML
      $html = '
        <div style="position: absolute; text-align: center; top: 10mm; line-height: 6.0;"> </div>
        <div style="position: absolute; text-align: center; top: 30mm; line-height: 1.5;">' . $name . '</div>
        <div style="position: absolute; text-align: center; top: 40mm; line-height: 1.5;">' . $courseName . '</div>
        <div style="position: absolute; text-align: center; top: 50mm; line-height: 1.5;">' . $courseDate . '</div>
      ';
      $pdf->writeHTML($html, true, false, false, false, '');

      // Output the PDF as a file with a unique filename based on user ID and timestamp
      $filename = 'certificate_' . time() . '.pdf';
      $pdf->Output(__DIR__.'/../../certificates/' . $filename, 'F');

      // Save certificate data in the database
      $insertCertificateQuery = "INSERT INTO certificates (user_id, course_id, certificate_name) VALUES ({$user['id']}, $courseId,  '$filename')";
      $mysqli->query($insertCertificateQuery);
      sleep(1); // The sleep time to avoid collision in creating 2 files

    }
  }
}
?>

<div class="card">
  <div class="card-body">
    <div class="content">

      <h2>Registered Users - <?php echo $course['title']; ?></h2>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Email</th>
              <th>Certificate</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($registeredUsers as $user): ?>
              <tr>
                <td><?php echo $user['id']; ?></td>
                <td><?php echo $user['name']; ?></td>
                <td><?php echo $user['email']; ?></td>
                <td>
                  <?php
                  $certificateQuery = "SELECT * FROM certificates WHERE user_id = {$user['id']} AND course_id = $courseId";
                  $certificateResult = $mysqli->query($certificateQuery);
                  $existingCertificate = $certificateResult->fetch_assoc();

                  if ($existingCertificate) {
                    echo "Yes";
                  } else {
                    echo "No";
                  }
                  ?>
                </td>
                <td>
                  <?php if ($existingCertificate): ?>
                    <form action="" method="post">
                      <input type="hidden" name="course_id" value="<?php echo $courseId; ?>">
                      <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                      <input type="hidden" name="certificate_name" value="<?php echo $existingCertificate['certificate_name']; ?>">
                      <button type="submit" class="btn btn-danger" name="delete_certificate">Delete Certificate</button>
                    </form>
                  <?php else: ?>
                    <form action="" method="post">
                      <input type="hidden" name="course_id" value="<?php echo $courseId; ?>">
                      <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                      <button type="submit" class="btn btn-primary" name="issue_single_certificate">Issue Certificate</button>
                    </form>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <form action="" method="post">
        <input type="hidden" name="course_id" value="<?php echo $courseId; ?>">
        <button type="submit" class="btn btn-primary" name="send_reminder">Send Reminder Email to Registered Users</button>
      </form>

      <form action="" method="post">
        <input type="hidden" name="course_id" value="<?php echo $courseId; ?>">
        <button type="submit" class="btn btn-success" name="issue_certificates">Issue Certificates to Registered Users</button>
      </form>

    </div>
  </div>
</div>

<?php include __DIR__.'/../template/footer.php'; ?>
