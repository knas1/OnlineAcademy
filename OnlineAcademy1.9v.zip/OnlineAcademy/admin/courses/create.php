<?php
$title = "Add courses";
$icon = "nc-layers-3";
include __DIR__.'/../template/header.php';

$errors = [];

// Fetch instructors from the database
$instructors = $mysqli->query("SELECT * FROM users where role='instructor';")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $course_title = mysqli_real_escape_string($mysqli, $_POST['course_title']);
  $course_description = mysqli_real_escape_string($mysqli, $_POST['course_description']);
  $course_link = mysqli_real_escape_string($mysqli, $_POST['course_link']);
  $course_status = $_POST['course_status'];
  $course_date = $_POST['course_date'];
  $course_capacity = $_POST['course_capacity'];
  $instructor_id = $_POST['instructor_id'];

  if (empty($course_title)) {
    array_push($errors, "Course title is required");
  }
  if (empty($course_description)) {
    array_push($errors, "Course description is required");
  }

  if (!count($errors)) {
    $st = $mysqli->prepare("INSERT INTO courses (title, description, link, status, date, capacity, instructor_id, image_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $st->bind_param("ssssssis", $course_title, $course_description, $course_link, $course_status, $course_date, $course_capacity, $instructor_id, $image_name);

    $st->execute();

    if ($st->error) {
      array_push($errors, $st->error);
    } else {
      echo "<script>location.href='index.php'</script>";
    }
  }

  // Image upload handling
  if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $image_temp = $_FILES['image']['tmp_name'];
    $image_name = uniqid('course_') . '_' . $_FILES['image']['name'];
    $image_path = '../../courses_image/' . $image_name;

    if (move_uploaded_file($image_temp, $image_path)) {
      // Save the image filename to the database
      $st = $mysqli->prepare("UPDATE courses SET image_path = ? WHERE title = ?");
      $st->bind_param("ss", $image_name, $course_title);
      $st->execute();
    } else {
      array_push($errors, "Failed to upload image. Please try again.");
    }
  }
}
?>

<div class="card">
  <div class="content">
    <?php include __DIR__.'/../template/errors.php'; ?>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="course_title">Title:</label>
        <input class="form-control" type="text" name="course_title" placeholder="Course Title" value="<?php echo isset($_POST['course_title']) ? $_POST['course_title'] : ''; ?>" id="course_title">
      </div>
      <div class="form-group">
        <label for="course_description">Description:</label>
        <textarea class="form-control" name="course_description" placeholder="Course Description" id="course_description"><?php echo isset($_POST['course_description']) ? $_POST['course_description'] : ''; ?></textarea>
      </div>
      <div class="form-group">
        <label for="course_link">Link:</label>
        <input class="form-control" type="text" name="course_link" placeholder="Course Link" value="<?php echo isset($_POST['course_link']) ? $_POST['course_link'] : ''; ?>" id="course_link">
      </div>
      <div class="form-group">
        <label for="course_status">Status:</label>
        <select class="form-control" name="course_status" id="course_status">
          <option value="upcoming">Upcoming</option>
          <option value="finished">Finished</option>
        </select>
      </div>
      <div class="form-group">
        <label for="course_date">Date:</label>
        <input class="form-control" type="text" name="course_date" placeholder="Course Date" value="<?php echo isset($_POST['course_date']) ? $_POST['course_date'] : ''; ?>" id="course_date">
      </div>
      <div class="form-group">
        <label for="course_capacity">Capacity:</label>
        <input class="form-control" type="text" name="course_capacity" placeholder="Course Capacity" value="<?php echo isset($_POST['course_capacity']) ? $_POST['course_capacity'] : ''; ?>" id="course_capacity">
      </div>
      <div class="form-group">
        <label for="instructor_id">Instructor:</label>
        <select class="form-control" name="instructor_id" id="instructor_id">
          <?php foreach ($instructors as $instructor): ?>
            <option value="<?php echo $instructor['id']; ?>"><?php echo $instructor['name']; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label for="image">Course Image:</label>
        <input class="form-control" type="file" name="image" id="image">
      </div>
      <div class="form-group">
        <button class="btn btn-success">Create</button>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__.'/../template/footer.php'; ?>
