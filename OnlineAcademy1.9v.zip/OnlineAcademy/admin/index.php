<?php
$title = "Dashboard";
$icon = "nc-grid-45";
include 'template/header.php';

 ?>



<?php include 'template/footer.php'; ?>
