<?php
$title = "Main Page";
require_once 'template/header.php';
$errors = [];
?>

<body>
    <?php include 'template/sidebar.php'; ?>
  <div class="content">
    <!-- Content based on the selected page -->
    <?php
    if (isset($_GET['page'])) {
      $page = $_GET['page'];

      if ($page === 'account') {
        // Display account management content
        include 'account.php';
      } elseif ($page === 'upcoming-courses') {
        // Display upcoming courses content
        include 'upcoming-courses.php';
      } elseif ($page === 'old-courses') {
        // Display old courses content
        include 'old-courses.php';
      } elseif ($page === 'contact') {
        // Display contact form
        include 'contact.php';
      }elseif ($page === 'my-courses') {
        // Display user's courses
        include 'my-courses.php';
      } elseif ($page === 'register') {
        // Display register form
        include 'register.php';
      } elseif ($page === 'login') {
        // Display login form
        include 'login.php';
      } elseif ($page === 'logout') {
        // Display login form
        include 'logout.php';
      } elseif ($page === 'reset_password') {
        // Display reset_password form
        include 'reset_password.php';
      }
    }
    ?>
  </div>

  <?php
  $mysqli->close();
  require_once 'template/footer.php';
  ?>
</body>

</html>
