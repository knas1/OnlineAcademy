<?php
$title = "Reset Password";
require_once 'template/header.php';
require_once 'config/database.php';
require_once 'sendMail.php'; // Include the sendEmail.php file for email sending functionality
?>

<?php
if (isset($_SESSION['logged_in'])) {
  header("location:". $config['app_url']);
  die();
}

$errors = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $email = mysqli_real_escape_string($mysqli, $_POST['email']);

  if (empty($email)) {
    array_push($errors, "Email is required");
  }

  if (!count($errors)) {
    $userExist = $mysqli->query("SELECT id,name,email,password FROM users WHERE email='$email' LIMIT 1");

    if ($userExist->num_rows) {
      $userId = $userExist->fetch_assoc()["id"];

      // Delete previous tokens
      $mysqli->query("DELETE FROM reset_password WHERE user_id = '$userId' ");

      // Generate special tokens
      $token = bin2hex(random_bytes(16));
      $expires_at = date("Y-m-d H:i:s", strtotime("+1 day"));

      $mysqli->query("INSERT INTO reset_password (user_id, token, expires_at)
                      VALUES ('$userId', '$token', '$expires_at')
      ");

      $changePasswordUrl = $config['app_url'] . 'change_password.php?token=' . $token;

      // Email sending code using sendEmail function from sendEmail.php
      $recipientEmail = $email;
      $subject = 'Password Reset Link';
      $message = 'Please click on the link below to reset your password: <br><br>'
                  . '<a href="' . $changePasswordUrl . '">Reset Password</a>';

      $emailSent = sendEmail($recipientEmail, $subject, $message);

      if ($emailSent) {
        $_SESSION['success_message'] = "Please check your email for the password reset link.";
      } else {
        array_push($errors,"Failed to send the password reset link. Please try again later.");
      }

      header('location: reset_password.php');
      die();
    }
  }
}
?>


<div class="password_reset">

  <h3 class="text-info">Please fill your Email</h3>
  <hr>

  <?php  include 'template/errors.php'; ?>
  <form action="" method="post">

    <div class="form-group">
      <label for="email">Email:</label>
      <input class="form-control" type="email" name="email" placeholder="Your Email" value="<?php echo $email; ?>" id="email">
    </div>

    <div class="form-groupd">
      <button class="btn btn-primary">Request Reset Password Link</button>
    </div>

  </form>

</div>





<?php
require_once 'template/footer.php';
 ?>
