<?php
$title = "Account Page";
require_once 'template/header.php';

$userId = $_SESSION['user_id'];

// Fetch the user's information from the database
$query = "SELECT * FROM users WHERE id = $userId";
$result = $mysqli->query($query);

if (!$result) {
  die('Error fetching user information: ' . $mysqli->error);
}

// Check if the user exists
if ($result->num_rows === 1) {
  $user = $result->fetch_assoc();
  $name = $user['name'];
  $email = $user['email'];
  $mobile = $user['mobile'];
  $hashedCurrentPassword = $user['password'];
} else {
  die('User not found.');
}

$errors = array(); // Initialize errors array

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Process the form submission and update the user's information in the database
  if (!empty($_POST['name'])) {
    $newName = $_POST['name'];
  }
  if (!empty($_POST['email'])) {
    $newEmail = $_POST['email'];
  }
  $newMobile = $_POST['mobile'];
  $newPassword = $_POST['password'];
  $confirmPassword = $_POST['confirm_password'];
  $currentPassword = $_POST['current_password'];

  // Check if any changes were made
  $changesMade = false;

  if (!empty($newName) && $newName !== $name) {
    $changesMade = true;
  }
  if (!empty($newEmail) && $newEmail !== $email) {
    $changesMade = true;
  }
  if ($newMobile !== $mobile) {
    $changesMade = true;
  }
  if (!empty($newPassword) && !empty($confirmPassword) && $newPassword === $confirmPassword) {
    // Check if the current password is correct
    if (password_verify($currentPassword, $hashedCurrentPassword)) {
      $newPassword = password_hash($newPassword, PASSWORD_DEFAULT);
      $changesMade = true;
    } else {
      array_push($errors, "Invalid current password");
    }
  }

  if ($changesMade) {
    // Update the user's information in the database
    $query = "UPDATE users SET name = '$newName', email = '$newEmail', mobile = '$newMobile', password = '$newPassword' WHERE id = $userId";
    $result = $mysqli->query($query);

    if ($result) {
      header("location: index.php?page=account");
      $_SESSION['success_message'] = "Your data has been updated successfully.";
    } else {
      echo 'Error updating user information: ' . $mysqli->error;
    }
  } else {
    $_SESSION['error_message'] = "No changes were made.";
  }
}
?>

<script>
  function updatePasswordRequirements() {
    const passwordInput = document.getElementById("password");
    const passwordConfirmationInput = document.getElementById("confirm_password");
    const passwordRequirements = document.getElementById("password-requirements");
    const requirementsList = document.getElementById("requirements-list");
    const passwordMismatch = document.getElementById("password-mismatch");

    const password = passwordInput.value;
    const passwordConfirmation = passwordConfirmationInput.value;

    // Check password length
    const lengthRequirement = password.length >= 8;
    // Check uppercase letter
    const uppercaseRequirement = /[A-Z]/.test(password);
    // Check lowercase letter
    const lowercaseRequirement = /[a-z]/.test(password);
    // Check number
    const numberRequirement = /\d/.test(password);

    // Update requirements list
    requirementsList.innerHTML = '';
    if (!lengthRequirement) requirementsList.innerHTML += '<li>Be at least 8 characters long</li>';
    if (!uppercaseRequirement) requirementsList.innerHTML += '<li>Contain at least one uppercase letter</li>';
    if (!lowercaseRequirement) requirementsList.innerHTML += '<li>Contain at least one lowercase letter</li>';
    if (!numberRequirement) requirementsList.innerHTML += '<li>Contain at least one number</li>';

    // Update passwordRequirements message
    if (lengthRequirement && uppercaseRequirement && lowercaseRequirement && numberRequirement) {
      passwordRequirements.style.color = 'green';
      passwordRequirements.innerHTML = 'Password meets the requirements.';
      requirementsList.style.display = 'none';
    } else {
      passwordRequirements.style.color = 'red';
      passwordRequirements.innerHTML = 'Password must:';
      requirementsList.style.display = 'block';
    }

    // Check password confirmation
    if (password === passwordConfirmation) {
      passwordMismatch.style.display = 'none';
    } else {
      passwordMismatch.style.display = 'block';
    }
  }

  function togglePasswordVisibility(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);

    if (input.type === "password") {
      input.type = "text";
      icon.classList.remove("fa-eye");
      icon.classList.add("fa-eye-slash");
    } else {
      input.type = "password";
      icon.classList.remove("fa-eye-slash");
      icon.classList.add("fa-eye");
    }
  }
</script>
<div class="container">
  <h2>Account Information</h2>
  <?php include 'template/errors.php'; ?>
  <form method="POST" action="" onkeyup="updatePasswordRequirements();">
    <div class="form-group">
      <label for="name">Name:</label>
      <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
    </div>
    <div class="form-group">
      <label for="mobile">Mobile:</label>
      <input class="form-control" type="tel" name="mobile" placeholder="05XXXXXXXX" value="<?php echo $mobile; ?>" id="mobile" pattern="05\d{8}" >
      <p class="text-muted">Mobile number must start with '05' and have 10 digits.</p>
    </div>
    <div class="form-group">
      <label for="current_password">Current Password:</label>
      <input type="password" class="form-control" id="current_password" name="current_password" value="">
    </div>
    <div class="form-group">
      <label for="password">New Password:</label>
      <div class="password-field">
        <input class="form-control" type="password" name="password" placeholder="Your password" id="password">
        <i id="toggle-password" class="fas fa-eye" onclick="togglePasswordVisibility('password', 'toggle-password')"></i>
      </div>
      <p id="password-requirements" style="color: red;">Password must:</p>
      <ul id="requirements-list" style="color: red;"></ul>
    </div>
    <div class="form-group">
      <label for="confirm_password">Confirm New Password:</label>
      <input type="password" class="form-control" id="confirm_password" name="confirm_password" value="">
      <p id="password-mismatch" style="color: red; display: none;">Passwords do not match.</p>
    </div>
    <button type="submit" class="btn btn-primary">Update</button>
  </form>
</div>

<?php
require_once 'template/footer.php';
?>
