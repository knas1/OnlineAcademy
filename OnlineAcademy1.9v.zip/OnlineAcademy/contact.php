<?php
$title = 'Contact Page';
require_once 'template/header.php';
require_once 'config/database.php';

$errors = [];
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbContacterName = mysqli_real_escape_string($mysqli, $_POST['name']);
    $dbEmail = mysqli_real_escape_string($mysqli, $_POST['email']);
    $dbMessage = mysqli_real_escape_string($mysqli, $_POST['message']);

    // Basic input validation
    if (empty($dbContacterName)) {
        $errors[] = 'Name is required.';
    }
    if (empty($dbEmail)) {
        $errors[] = 'Email is required.';
    } elseif (!filter_var($dbEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format.';
    }
    if (empty($dbMessage)) {
        $errors[] = 'Message is required.';
    }

    // If there are no validation errors, proceed with inserting data into the database
    if (empty($errors)) {
        $InsertQuery = $mysqli->prepare("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)");
        $InsertQuery->bind_param("sss", $dbContacterName, $dbEmail, $dbMessage);
        $InsertQuery->execute();
        $InsertQuery->close();

        $success_message = 'Message sent successfully!';
    }
}

?>

<h1>Contact us</h1>

<?php include 'template/errors.php'; ?>

<?php if (!empty($success_message)) : ?>
    <div class="alert alert-success">
        <?php echo $success_message; ?>
    </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">

    <div class="form-group">
        <label for="name">Your name</label>
        <input type="text" value="<?php echo isset($_POST["name"]) ? htmlspecialchars($_POST["name"]) : ''; ?>" name="name" class="form-control" placeholder="Your name">
    </div>

    <div class="form-group">
        <label for="email">Your email</label>
        <input type="email" value="<?php echo isset($_POST["email"]) ? htmlspecialchars($_POST["email"]) : ''; ?>" name="email" class="form-control" placeholder="Your email">
    </div>

    <div class="form-group">
        <label for="message">Message</label>
        <textarea name="message" class="form-control" rows="8" cols="80"><?php echo isset($_POST["message"]) ? htmlspecialchars($_POST["message"]) : ''; ?></textarea>
    </div>

    <button class="btn btn-primary">Send</button>
</form>

<?php require_once 'template/footer.php'; ?>
