<?php
require_once 'template/header.php';
$errors = [];
?>

<div class="container">
  <h2>Old Courses</h2>
  <?php include 'template/errors.php'; ?>
  <style>
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }

    .course-boxes {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      gap: 20px;
      margin-top: 20px;
    }

    .course-box {
      flex-basis: calc(33.33% - 20px); /* Show 3 boxes per row, adjust to 50% for 2 boxes per row */
      border: 1px solid #ccc;
      padding: 20px;
      border-radius: 5px;
    }

    .course-box h3 {
      margin-top: 0;
    }

    .actions {
      margin-top: 10px;
    }

    .actions button,
    .actions p {
      margin-right: 10px;
    }

    .text-danger {
      color: red;
    }

    .text-info {
      color: blue;
    }

    /* Media query for 2 boxes per row on smaller screens */
    @media (max-width: 768px) {
      .course-box {
        flex-basis: calc(50% - 20px);
      }
    }
    .course-box img {
      width: 100%;
      border-radius: 5px;
      margin-bottom: 10px;
    }
  </style>

  <div class="course-boxes">
    <?php
    // Fetch old courses from the database (courses with status = "finished")
    $query = 'SELECT c.*, u.name AS instructor_name FROM courses AS c
              LEFT JOIN users AS u ON c.instructor_id = u.id
              WHERE c.status = "finished"';
    $result = $mysqli->query($query);

    if (!$result) {
      die('Error fetching finished courses: ' . $mysqli->error);
    }

    // Process the fetched courses
    while ($row = $result->fetch_assoc()) {
      // Display course information
      echo '<div class="course-box">';
      echo '<h3>' . $row['title'] . '</h3>';
      echo '<img src="courses_image/' . $row['image_path'] . '" alt="Unavailable Photo">';
      echo '<p>' . $row['description'] . '</p>';
      echo '<p>Date: ' . date('F j, Y', strtotime($row['date'])) . '</p>';
      echo '<p>Instructor: ' . $row['instructor_name'] . '</p>'; // Display the instructor's name
      echo '<div class="actions">';

      // Display a message indicating that registration is closed for old courses
      echo '<p class="text-danger">Registration Closed</p>';

      echo '</div>'; // End of actions
      echo '</div>'; // End of course-box
    }
    ?>
  </div> <!-- End of course-boxes -->
</div>

<?php
require_once 'template/footer.php';
?>
