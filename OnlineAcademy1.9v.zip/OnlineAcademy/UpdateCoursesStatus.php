<?php

// Get the current date in the format "YYYY-MM-DD"
$currentDate = date('Y-m-d');

// Query to update the status of upcoming courses to "finished"
$updateQuery = "UPDATE courses SET status = 'finished' WHERE status = 'upcoming' AND date < '$currentDate'";

// Execute the update query
$mysqli->query($updateQuery);


?>
