<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

function sendEmail($recipientEmail, $subject, $message) {
  $mail = new PHPMailer(true);

  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = true;
  $mail->Username = 'skotershot76@gmail.com'; // Replace with your Gmail email
  $mail->Password = 'gbyxvmxjwnljplsn'; // Replace with your Gmail app password or account password
  $mail->SMTPSecure = 'ssl';
  $mail->Port = 465;

  $mail->setFrom('skotershot76@gmail.com'); // Replace with your Gmail email

  $mail->addAddress($recipientEmail);

  $mail->isHTML(false);

  $mail->Subject = $subject;
  $mail->Body = $message;

  try {
    $mail->send();
    return 'Reminder Email Sent Successfully';
  } catch (Exception $e) {
    return 'Reminder Email could not be sent. Error: ' . $mail->ErrorInfo;
  }
}
?>
