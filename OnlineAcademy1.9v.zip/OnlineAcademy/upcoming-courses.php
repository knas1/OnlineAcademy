<?php
require_once 'template/header.php';
require_once 'UpdateCoursesStatus.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $courseId = $_POST['course_id'];

  // Check if the user is logged in
  if ($_SESSION['logged_in'] == true) {
    // Check if the course exists
    $query = "SELECT * FROM courses WHERE id = $courseId";
    $result = $mysqli->query($query);

    if ($result->num_rows === 1) {
      $course = $result->fetch_assoc();
      $capacity = $course['capacity'];
      $takenSeats = $course['taken_seats'];

      // Check if the user is already registered for the course
      $userId = $_SESSION['user_id'];
      $registrationQuery = "SELECT * FROM registrations WHERE user_id = $userId AND course_id = $courseId";
      $registrationResult = $mysqli->query($registrationQuery);

      if ($registrationResult->num_rows === 0) {
        // Check if there are available seats
        if ($capacity === null || $takenSeats < $capacity) {
          // Update the taken_seats count
          $newTakenSeats = $takenSeats + 1;
          $updateQuery = "UPDATE courses SET taken_seats = $newTakenSeats WHERE id = $courseId";

          if ($mysqli->query($updateQuery)) {
            // Insert registration information into the registrations table
            $insertQuery = "INSERT INTO registrations (user_id, course_id) VALUES ($userId, $courseId)";
            $mysqli->query($insertQuery);
            $_SESSION['success_message'] = "Seat reserved successfully!";
            header("Refresh:0");
          } else {
            array_push($errors, "Failed to reserve seat. Please try again.");
          }
        } else {
          array_push($errors, "No available seats.");
        }
      } else {
        array_push($errors, "You are already registered for this course.");
      }
    } else {
      array_push($errors, "Invalid course.");
    }
  } else {
    array_push($errors, "Please log in to reserve a seat.");
  }
}
?>

<div class="container">
  <h2>Upcoming Courses</h2>
  <?php include 'template/errors.php'; ?>
  <style>
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }

    .course-boxes {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      gap: 20px;
      margin-top: 20px;
    }

    .course-box {
      flex-basis: calc(33.33% - 20px); /* Show 3 boxes per row, adjust to 50% for 2 boxes per row */
      border: 1px solid #ccc;
      padding: 20px;
      border-radius: 5px;
    }

    .course-box h3 {
      margin-top: 0;
    }

    .actions {
      margin-top: 10px;
    }

    .actions button,
    .actions p {
      margin-right: 10px;
    }

    .text-danger {
      color: red;
    }

    .text-info {
      color: blue;
    }

    /* Media query for 2 boxes per row on smaller screens */
    @media (max-width: 768px) {
      .course-box {
        flex-basis: calc(50% - 20px);
      }
    }
    .course-box img {
      width: 100%;
      border-radius: 5px;
      margin-bottom: 10px;
    }
  </style>

  <div class="course-boxes">
    <?php
    // Fetch upcoming courses from the database
    $query = 'SELECT c.*, u.name AS instructor_name FROM courses AS c
              LEFT JOIN users AS u ON c.instructor_id = u.id
              WHERE c.status = "upcoming"';
    $result = $mysqli->query($query);

    if (!$result) {
      die('Error fetching upcoming courses: ' . $mysqli->error);
    }

    // Process the fetched courses
    while ($row = $result->fetch_assoc()) {
      // Check if the user is already registered for the course (unchanged from existing code)
      if (isset($_SESSION['logged_in'])) {
        $userId = $_SESSION['user_id'];
        $courseId = $row['id'];
        $registrationQuery = "SELECT * FROM registrations WHERE user_id = $userId AND course_id = $courseId";
        $registrationResult = $mysqli->query($registrationQuery);
      }

      // Display course information
      echo '<div class="course-box">';
      echo '<h3>' . $row['title'] . '</h3>';
      echo '<img src="courses_image/' . $row['image_path'] . '" alt="Unavailable Photo">';
      echo '<p>' . $row['description'] . '</p>';
      echo '<p>Date: ' . date('F j, Y', strtotime($row['date'])) . '</p>';
      echo '<p>Instructor: ' . $row['instructor_name'] . '</p>'; // Display the instructor's name
      echo '<div class="actions">';


      // Check if the user is logged in
      if (isset($_SESSION['logged_in'])) {
        // Check if the user is already registered for the course
        if ($registrationResult->num_rows === 0) {
          // Check if there are available seats
          if ($row['capacity'] === null || $row['taken_seats'] < $row['capacity']) {
            // Display the reserve seat button
            echo '<form action="" method="post">';
            echo '<input type="hidden" name="course_id" value="' . $row['id'] . '">';
            echo '<button type="submit" class="btn btn-primary">Reserve Seat</button>';
            echo '</form>';
          } else {
            // Display no available seats message
            echo '<p class="text-danger">No available seats</p>';
          }
        } else {
          // Display already registered message
          echo '<p class="text-info">Already registered</p>';
        }
      } else {
        // Display login message
        echo '<p class="text-info">Please log in to reserve a seat</p>';
      }

      echo '</div>'; // End of actions
      echo '</div>'; // End of course-box
    }
    ?>
  </div> <!-- End of course-boxes -->
</div>

<?php
require_once 'template/footer.php';
?>
